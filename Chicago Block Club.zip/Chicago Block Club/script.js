const apiKey = 'b2a87b5ff6a5493694e151e91658bb4c';
const pageSize = 6;
let currentPage = 1;
let currentCategory = 'general';

const apiUrl = `https://newsapi.org/v2/top-headlines?country=US&apiKey=${apiKey}&pageSize=${pageSize}`;

const newsDiv = document.getElementById('news');

// Define the category URLs
const categoryUrls = {
  'general': `${apiUrl}&category=general`,
  'sports': `${apiUrl}&category=sports`,
  'health': `${apiUrl}&category=health`
};

// Add event listeners to the navbar links
const navLinks = document.querySelectorAll('nav a');
navLinks.forEach(link => {
  link.addEventListener('click', () => {
    // Remove the "active" class from all links
    navLinks.forEach(link => link.classList.remove('active'));

    // Add the "active" class to the clicked link
    link.classList.add('active');

    // Get the category URL for the clicked link
    const categoryUrl = categoryUrls[link.innerHTML.toLowerCase()];

    // Set the current category and reset the current page
    currentCategory = link.innerHTML.toLowerCase();
    currentPage = 1;

    // Fetch the news data for the selected category and page
    fetchNews(categoryUrl, currentPage);
  });
});

// Add event listeners to the pagination buttons
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
prevBtn.addEventListener('click', () => {
  if (currentPage > 1) {
    currentPage--;
    fetchNews(categoryUrls[currentCategory], currentPage);
  }
});
nextBtn.addEventListener('click', () => {
  currentPage++;
  fetchNews(categoryUrls[currentCategory], currentPage);
});

// Fetch the news data for the specified category and page
function fetchNews(url, page) {
  // Add the page parameter to the URL
  const urlWithPage = `${url}&page=${page}`;

  // Fetch the news data for the specified URL
  fetch(urlWithPage)
    .then(response => response.json())
    .then(data => {
      // Clear the existing news content
      newsDiv.innerHTML = '';

      // Create article elements for each article
      const articles = data.articles;
      articles.forEach(article => {
        const articleDiv = document.createElement('div');
        articleDiv.className = 'article';

        const img = document.createElement('img');
        img.src = article.urlToImage;
        articleDiv.appendChild(img);

        const title = document.createElement('h2');
        title.innerHTML = article.title;
        articleDiv.appendChild(title);

        const description = document.createElement('p');
        description.innerHTML = article.description;
        articleDiv.appendChild(description);

        const url = document.createElement('a');
        url.href = article.url;
        url.innerHTML = 'Read More';
        articleDiv.appendChild(url);

        newsDiv.appendChild(articleDiv);
      });
      

      // Update the pagination buttons
      const totalResults = data.totalResults;
      const totalPages = Math.ceil(totalResults / pageSize);

      // Disable the "Previous" button if on the first page
      if (currentPage === 1) {
        prevBtn.classList.add('disabled');
      } else {
        prevBtn.classList.remove('disabled');
      }

      // Disable the "Next" button if on the last page
      if (currentPage === totalPages) {
        nextBtn.classList.add('disabled');
      } else {
        nextBtn.classList.remove('disabled');
      }
    });
}

// Show the news for the "General" category by default
fetchNews(categoryUrls.general, 1);







// const apiKey = 'b2a87b5ff6a5493694e151e91658bb4c';
// const apiUrl = `https://newsapi.org/v2/top-headlines?country=US&apiKey=${apiKey}&pageSize=6`;

// const newsDiv = document.getElementById('news');

// // Define the category URLs
// const categoryUrls = {
//   'general': `${apiUrl}&category=general`,
//   'sports': `${apiUrl}&category=sports`,
//   'health': `${apiUrl}&category=health`
// };

// // Add event listeners to the navbar links
// const navLinks = document.querySelectorAll('nav a');
// navLinks.forEach(link => {
//   link.addEventListener('click', () => {
//     // Remove the "active" class from all links
//     navLinks.forEach(link => link.classList.remove('active'));

//     // Add the "active" class to the clicked link
//     link.classList.add('active');

//     // Get the category URL for the clicked link
//     const categoryUrl = categoryUrls[link.innerHTML.toLowerCase()];

//     // Fetch the news data for the selected category
//     fetch(categoryUrl)
//       .then(response => response.json())
//       .then(data => {
//         // Clear the existing news content
//         newsDiv.innerHTML = '';

//         // Create article elements for each article
//         const articles = data.articles;
//         articles.forEach(article => {
//           const articleDiv = document.createElement('div');
//           articleDiv.className = 'article';

//           const img = document.createElement('img');
//           img.src = article.urlToImage;
//           articleDiv.appendChild(img);

//           const title = document.createElement('h2');
//           title.innerHTML = article.title;
//           articleDiv.appendChild(title);

//           const description = document.createElement('p');
//           description.innerHTML = article.description;
//           articleDiv.appendChild(description);

//           const url = document.createElement('a');
//           url.href = article.url;
//           url.innerHTML = 'Read More';
//           articleDiv.appendChild(url);

//           newsDiv.appendChild(articleDiv);
//         });
//       });
//   });
// });

// // Show the news for the "General" category by default
// fetch(categoryUrls.general)
//   .then(response => response.json())
//   .then(data => {
//     // Clear the existing news content
//     newsDiv.innerHTML = '';

//     // Create article elements for each article
//     const articles = data.articles;
//     articles.forEach(article => {
//       const articleDiv = document.createElement('div');
//       articleDiv.className = 'article';

//       const img = document.createElement('img');
//       img.src = article.urlToImage;
//       articleDiv.appendChild(img);

//       const title = document.createElement('h2');
//       title.innerHTML = article.title;
//       articleDiv.appendChild(title);

//       const description = document.createElement('p');
//       description.innerHTML = article.description;
//       articleDiv.appendChild(description);

//       const url = document.createElement('a');
//       url.href = article.url;
//       url.innerHTML = 'Read More';
//       articleDiv.appendChild(url);

//       newsDiv.appendChild(articleDiv);
//     });
//   });



