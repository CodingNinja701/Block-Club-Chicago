
  const subscribeBtn = document.getElementById('subscribeBtn');
  const subscribeModal = document.getElementById('subscribeModal');
  
  subscribeBtn.addEventListener('click', function() {
    $('#subscribeModal').modal('show');
  });


  function showLoginForm() {
    document.getElementById("login-form").style.display = "block";
    document.getElementById("signup-form").style.display = "none";
  }

  function showSignupForm() {
    document.getElementById("signup-form").style.display = "block";
    document.getElementById("login-form").style.display = "none";
  }